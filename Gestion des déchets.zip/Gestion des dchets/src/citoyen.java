import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("b095269c-aad8-4976-a486-c859c2dbba5d")
public class citoyen {
    @objid ("937c3ba6-c5b3-46aa-8e9e-c7f492502a32")
    public int idCitoyen;

    @objid ("a6fa00f6-3b1f-4abb-ba2d-283605fa7676")
    public String nom;

    @objid ("abf18de0-c93a-4332-8a70-7da81bd7be3f")
    public String prenom;

    @objid ("9d0f7022-e5f5-4287-a67e-08b48b70080b")
    public int numTel;

    @objid ("dcc33eea-e7bb-4f03-868a-06c761d9afe7")
    public List<Signalement>  = new ArrayList<Signalement> ();

    @objid ("b62118a0-b01a-4b13-9df7-93cf9cd22afc")
    public void signaler() {
    }

    @objid ("b4acea32-059c-40aa-b616-ea90a2db4f5f")
    public void suivre() {
    }

}

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("73e4156a-b171-42ef-b89b-fbc1c3080bf4")
public class Singleton {
    @objid ("6d2367f4-b8ba-4bce-976b-3e7d81142f1a")
    private static Singleton Instance;

    @objid ("8b868a42-66ba-4538-b43f-42d5d088e045")
    private Singleton() {
    }

    @objid ("76c73f42-0ea0-41fa-8e2c-aff35fe95606")
    public static Singleton getInstance() {
        // TODO Auto-generated return
        return null;
    }

}

import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("dceb030a-6df9-4ede-a124-152492f21196")
public class Agent {
    @objid ("664c74a3-c5cc-45a3-821f-106418103256")
    public String idAgent;

    @objid ("2202cada-1ad1-4a57-a7ad-8159e2c7d8da")
    public String nom;

    @objid ("f23053cf-74fa-4fa0-aa22-5b2059dce6a0")
    public String role = collecte/tri;

    @objid ("8f19421b-0c75-43c4-bdc0-46a4316b9573")
    public List<Collecte>  = new ArrayList<Collecte> ();

    @objid ("c0bd6616-5327-4774-9fbb-da94cc4f0e14")
    public List<Signalement>  = new ArrayList<Signalement> ();

    @objid ("79c9c038-ae97-4849-b9ac-2d70ad23ed5e")
    public void traiterSignalement() {
    }

    @objid ("0bc59467-d123-467e-aff1-5d8d0bcd0724")
    public void collecter() {
    }

}

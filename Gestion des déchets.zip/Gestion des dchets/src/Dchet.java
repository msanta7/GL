import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("b038fe7a-fa89-4e98-b6e9-a63ff7ccb364")
public class Déchet {
    @objid ("4bd8b6d2-a46d-40a1-8925-e961a3553fb1")
    public int idDechet;

    @objid ("742f23ea-20b7-43d2-901d-0597339c2876")
    public String type;

    @objid ("924e4b34-dee1-411c-b45f-f1f357192357")
    public String description;

}

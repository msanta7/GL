import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("deb7ffda-d520-4430-8a7a-4f792c4384e7")
public class Collecte {
    @objid ("1a27f587-3ae0-4061-942b-c85fdbe93e23")
    public int idCollecte;

    @objid ("3b50cfbd-2860-4d90-9dc1-7e649574bde1")
    public Date dateCollecte;

    @objid ("8b8067f7-1bcc-4c0c-aab7-18ee2e6c336b")
    public double quantite;

    @objid ("ef692283-ce18-4051-b796-451fa4933dfb")
    public List<Déchet>  = new ArrayList<Déchet> ();

}

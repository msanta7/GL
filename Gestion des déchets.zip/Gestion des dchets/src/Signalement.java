import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("8e19b20b-3b6a-4132-a8e7-9a809267454a")
public class Signalement {
    @objid ("3e4a50fc-dc54-4a67-88c9-f0b0d4c826c4")
    public int idSignalement;

    @objid ("912f3671-4017-42cf-9006-5a5115444862")
    public Date dateSignalement;

    @objid ("706d8900-424d-4654-a7ab-1a6fa35455c4")
    public String statut;

    @objid ("65049054-b37a-4911-b5e5-91d9a7b4f6d0")
    public String adresse;

    @objid ("ab6bb8d6-46cb-4cb8-88a4-d1693cfdc2cd")
    public List<Déchet> déchet = new ArrayList<Déchet> ();

    @objid ("dba1cf23-072f-421b-bd2c-7202cfee2d48")
    public void metaJourStatut() {
    }

}
